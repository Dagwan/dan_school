module.exports = {
    testMatch: ['**/__tests__/**/*.test.js'],
  };
  