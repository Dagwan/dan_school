const express = require('express');
const bodyParser = require('body-parser');
const authMiddleware = require('./middleware/authMiddleware');
const errorMiddleware = require('./middleware/errorMiddleware');
const authRoutes = require('./routes/auth');
const app = express();

app.use(bodyParser.json());
app.use('/auth', authRoutes);

// Define a route for the root path
app.get('/', (req, res) => {
  res.send('Welcome to your application!');
});

// Error handling middleware
app.use(errorMiddleware.errorHandler);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
