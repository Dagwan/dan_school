const express = require('express');
const crypto = require('crypto');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { sendVerificationEmail } = require('../services/emailService');
const { db } = require('../services/db'); // Import your MySQL database connection


router.post('/register', async (req, res) => {
  try {
    const { email, password, firstName, lastName, otherName, contactAddress, permanentAddress, nationality, country, lga, state, zipCode, phone } = req.body;

    const hashedPassword = await bcrypt.hash(password, 10);
    const verificationToken = crypto.randomBytes(32).toString('hex');

    // Save user data and verification token in the database
    await db.query('INSERT INTO users (email, password, verificationToken, firstName, lastName, otherName, contactAddress, permanentAddress, nationality, country, lga, state, zipCode, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [email, hashedPassword, verificationToken, firstName, lastName, otherName, contactAddress, permanentAddress, nationality, country, lga, state, zipCode, phone]);

    // Send verification email
    sendVerificationEmail(email, verificationToken);

    res.status(201).json({ message: 'Account created successfully. Please check your email to verify your account.' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'An error occurred while creating an account.' });
  }
});



// Create other routes for account verification, login, and form submission
router.get('/verify', async (req, res) => {
  try {
    const { token } = req.query;
    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);

    // Update user's verified status in the database
    await db.query('UPDATE users SET verified = true WHERE email = ?', [decodedToken.email]);

    res.redirect(`${process.env.CLIENT_URL}/login?message=Your account has been verified. Please log in.`);
  } catch (error) {
    console.error(error);
    res.redirect(`${process.env.CLIENT_URL}/login?message=Account verification failed.`);
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await db.query('SELECT * FROM users WHERE email = ?', [email]);
    if (!user.length) {
      return res.status(401).json({ message: 'Invalid credentials.' });
    }

    const passwordMatch = await bcrypt.compare(password, user[0].password);
    if (!passwordMatch) {
      return res.status(401).json({ message: 'Invalid credentials.' });
    }

    if (!user[0].verified) {
      return res.status(401).json({ message: 'Account not verified yet.' });
    }

    const token = jwt.sign({ id: user[0].id, email: user[0].email }, process.env.JWT_SECRET);
    res.status(200).json({ token });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'An error occurred while logging in.' });
  }
});


router.post('/submitForm', async (req, res) => {
  try {
    const { id } = req.user; // User ID from JWT
    const { parentData, childData, documentData } = req.body;

    // Insert parent/guardian data
    const parentInsertResult = await db.query(
      'INSERT INTO parent_guardian (user_id, title, first_name, last_name, email, phone_number, relationship, address_line1, address_line2, postal_code, nationality, local_government_area, city, state_of_origin, employment_history, employer_name, legal_custody, primary_contact, responsible_for_fees, emergency_contact) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [
        id, 
        parentData.title,
        parentData.firstName,
        parentData.lastName,
        parentData.email,
        parentData.phoneNumber,
        parentData.relationship,
        parentData.addressLine1,
        parentData.addressLine2,
        parentData.postalCode,
        parentData.nationality,
        parentData.localGovernmentArea,
        parentData.city,
        parentData.stateOfOrigin,
        parentData.employmentHistory,
        parentData.employerName,
        parentData.legalCustody,
        parentData.primaryContact,
        parentData.responsibleForFees,
        parentData.emergencyContact
      ]
    );

    const parentId = parentInsertResult.insertId; // Retrieve the ID of the inserted parent/guardian

    // Insert child data
    const childInsertResult = await db.query(
      'INSERT INTO child (parent_id, first_name, last_name, preferred_name, date_of_birth, gender, native_language, second_language, first_nationality, second_nationality, country_of_birth, city_of_birth, ethnicity, religion, passport_id_number, preferred_enrolment_date, need_i20, english_spoken, english_written, progress_concerns, progress_concerns_details, additional_needs, external_support, external_support_details, medical_conditions, medical_conditions_details, allergies, allergies_details, attended_previous_school, previous_school_name, previous_year_grade, attended_from, attended_to, previous_school_country, previous_school_city, previous_school_curriculum, previous_school_language, contact_previous_school, reason_for_leaving, expulsion_history, expulsion_details, special_interest) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [
        parentId,
        childData.firstName,
        childData.lastName,
        childData.preferredName,
        childData.dateOfBirth,
        childData.gender,
        childData.nativeLanguage,
        childData.secondLanguage,
        childData.firstNationality,
        childData.secondNationality,
        childData.countryOfBirth,
        childData.cityOfBirth,
        childData.ethnicity,
        childData.religion,
        childData.passportIdNumber,
        childData.preferredEnrolmentDate,
        childData.needI20,
        childData.englishSpoken,
        childData.englishWritten,
        childData.progressConcerns,
        childData.progressConcernsDetails,
        childData.additionalNeeds,
        childData.externalSupport,
        childData.externalSupportDetails,
        childData.medicalConditions,
        childData.medicalConditionsDetails,
        childData.allergies,
        childData.allergiesDetails,
        childData.attendedPreviousSchool,
        childData.previousSchoolName,
        childData.previousYearGrade,
        childData.attendedFrom,
        childData.attendedTo,
        childData.previousSchoolCountry,
        childData.previousSchoolCity,
        childData.previousSchoolCurriculum,
        childData.previousSchoolLanguage,
        childData.contactPreviousSchool,
        childData.reasonForLeaving,
        childData.expulsionHistory,
        childData.expulsionDetails,
        childData.specialInterest
      ]
    );

    const childId = childInsertResult.insertId; // Retrieve the ID of the inserted child

    // Insert child documents data
    for (const document of documentData) {
      await db.query(
        'INSERT INTO child_documents (child_id, document_type, file_path) VALUES (?, ?, ?)',
        [childId, document.documentType, document.filePath]
      );
    }

    res.status(200).json({ message: 'Form submitted successfully.' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'An error occurred while submitting the form.' });
  }
});

module.exports = router;

